package com.example.oman.mywallpaper;

import android.app.WallpaperManager;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    GridView myGridView;
    ImageView myCurrentWallpaper;
    Drawable myDrawable;
    WallpaperManager myWallManager;

    Integer[] myImageArray = {
            R.drawable.thumb1, R.drawable.thumb2, R.drawable.thumb3,
            R.drawable.thumb4, R.drawable.thumb5, R.drawable.thumb6,
            R.drawable.thumb7, R.drawable.thumb8
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myGridView = findViewById(R.id.myGridView);
        myCurrentWallpaper=findViewById(R.id.myImageView);
        updateMyWallpaper();

    }

    private void updateMyWallpaper() {
        myWallManager = WallpaperManager.getInstance(getApplicationContext());
        myDrawable = myWallManager.getDrawable();
        myCurrentWallpaper.setImageDrawable(myDrawable);
    }
}
